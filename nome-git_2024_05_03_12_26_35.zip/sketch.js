function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  text ("L", 200,200);
  fill(color ("purple"));
}